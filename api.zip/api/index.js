import mysql from 'mysql2/promise';

// Konfigurasi Database diambil dari Environment Variables Vercel
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306
};

export default async function handler(req, res) {
    // Hanya menerima method POST untuk keamanan data transaksi
    if (req.method !== 'POST') {
        return res.status(405).json({ success: false, message: 'Method tidak diizinkan. Gunakan POST.' });
    }

    try {
        const { kode_transaksi, tipe_dana, username_target, nominal } = req.body;

        // Validasi input data wajib
        if (!kode_transaksi || !tipe_dana || !username_target || !nominal) {
            return res.status(400).json({ 
                success: false, 
                message: 'Data tidak lengkap! Kirimkan kode_transaksi, tipe_dana, username_target, dan nominal.' 
            });
        }

        // Validasi tipe dana apakah untuk admin atau player
        if (tipe_dana !== 'admin' && tipe_dana !== 'player') {
            return res.status(400).json({ success: false, message: 'tipe_dana harus berupa "admin" atau "player".' });
        }

        // Koneksi ke MySQL Cloud
        const connection = await mysql.createConnection(dbConfig);
        
        // Query untuk menyimpan data transaksi (Waktu otomatis terisi menggunakan NOW())
        const query = `
            INSERT INTO transaksi_pending (kode_transaksi, tipe_dana, username_target, nominal, waktu_transfer, status) 
            VALUES (?, ?, ?, ?, NOW(), 0)
        `;
        
        await connection.execute(query, [kode_transaksi, tipe_dana, username_target, parseInt(nominal)]);
        await connection.end();

        return res.status(200).json({ 
            success: true, 
            message: `Transaksi ${tipe_dana} sebesar Rp${nominal} untuk ${username_target} berhasil disimpan!` 
        });

    } catch (error) {
        // Deteksi jika kode transaksi sudah ada di database (Duplikat)
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ success: false, message: 'Kode transaksi ini sudah terdaftar sebelumnya!' });
        }
        return res.status(500).json({ success: false, error: error.message });
    }
}